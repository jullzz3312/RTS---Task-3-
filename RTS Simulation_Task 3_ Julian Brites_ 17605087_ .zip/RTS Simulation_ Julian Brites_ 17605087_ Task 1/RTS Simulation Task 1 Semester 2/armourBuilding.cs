﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace RTS_Simulation_Task_1_Semester_2
{
    class armourBuilding : Building
    {
        private int armourPerSecond = 1;
        private int totalArmour;
        private int armourRemaining;

        public armourBuilding(int posX, int posY, int hP, string faction, string symbol)
             : base(posX, posY, hP, faction, symbol)
        {

        }

        public override bool isAlive()
        {
            return (HP >= 0);
        }

        public override string toString()
        {
            string output;

            output = "X Co-ordinate:" + POSX + "\n";
            output = "Y Co-ordinate:" + POSY + "\n";
            output += "Health: " + HP + "\n";
            output += "Faction:" + Faction + "\n";
            output += "Symbol:" + Symbol + "\n";

            return output;
        }

        public void unitArmour()
        {
            if (armourRemaining >= 0)
                armourRemaining -= armourPerSecond;

        }

        public void armourRemoval()
        {
            int maxArmour = 100;
            armourRemaining = maxArmour - totalArmour;
        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                // open the file
                outFile = new FileStream("Files\\MapObjects.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);

                // write to the file
                writer.WriteLine(POSX);
                writer.WriteLine(POSY);
                writer.WriteLine(HP);
                writer.WriteLine(Faction);
                writer.WriteLine(Symbol);

                // close the file
                writer.Close();
                outFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (outFile != null)
                {
                    outFile.Close();
                    writer.Close();
                }
            }
        }
    }
}
