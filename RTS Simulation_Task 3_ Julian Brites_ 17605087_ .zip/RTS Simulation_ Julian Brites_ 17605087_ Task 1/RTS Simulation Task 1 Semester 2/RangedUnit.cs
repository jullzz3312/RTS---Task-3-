﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;


namespace RTS_Simulation_Task_1_Semester_2
{
    class RangedUnit : Unit
    {
        private int Damage = 6;

        public RangedUnit(int xPos, int yPos, int health, int speed, bool attack, int attackRange, string faction, string symbol, int isAttacking, string name)
           : base(xPos, yPos, health, speed, attack, attackRange, faction, symbol, isAttacking, name)
        {
        }

        public override void movePosition(int xPos, int yPos)
        {
            if (xPos >= 0 && xPos < 20)
            {
                XPos = xPos;
            }
            if (yPos >= 0 && yPos < 20)
            {
                YPos = yPos;
            }
        }

        public override void combat(Unit enemy)
        {
            if (this.isWithinAttackRange(enemy))
            {
                enemy.Health -= Damage;
            }
        }

        public override bool isWithinAttackRange(Unit enemy)
        {

            if (!this.Faction.Equals(enemy.Faction))
            {
                if ((Math.Abs(this.XPos - enemy.XPos) <= this.AttackRange) && (Math.Abs(this.YPos - enemy.YPos) <= this.AttackRange))
                    return true;
                else
                    return false;
            }
            else
                return false;
        }

        public override Unit closestUnit(List<Unit> list)
        {
            Unit closest = null;
            int attackRangeX, attackRangeY;
            double range;
            double shortestRange = 1000;

            foreach (Unit u in list)
            {
                attackRangeX = Math.Abs(this.XPos - u.XPos);
                attackRangeY = Math.Abs(this.YPos - u.YPos);

                range = Math.Sqrt(Math.Pow(attackRangeX, 2) + Math.Pow(attackRangeY, 2));

                if (range < shortestRange)
                {
                    shortestRange = range;
                    closest = u;
                }
            }
            return closest;
        }

        public void unitFear()
        {
            if (Health <= 25)
            {
                movePosition(XPos, YPos);
                Globals.m.warzone();
            }
        }

        public override bool isAlive()
        {
            return (Health <= 0);
        }

        public override string toString()
        {
            string output;

            output = "X Co-ordinate: " + XPos + "\n";
            output += "Y Co-ordinate: " + YPos + "\n";
            output += "Health: " + Health + "\n";
            output += "Speed: " + Speed + "\n";
            output += "Attacking: " + (Attack ? "Yes" : "No") + "\n";
            output += "Attack Range: " + AttackRange + "\n";
            output += "Faction: " + Faction + "\n";
            output += "Symbol: " + Symbol + "\n";
            output += "Name: " + Name + "\n";

            return output;

        }

        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                // open the file
                outFile = new FileStream("Files\\MapObjects.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);

                // write to the file
                writer.WriteLine(XPos);
                writer.WriteLine(YPos);
                writer.WriteLine(Health);
                writer.WriteLine(Speed);
                writer.WriteLine(Attack);
                writer.WriteLine(AttackRange);
                writer.WriteLine(Faction);
                writer.WriteLine(Symbol);
                writer.WriteLine(IsAttacking);
                writer.WriteLine(Name);
                // close the file
                writer.Close();
                outFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);       
            }
            finally
            {
                if (outFile != null)   
                {
                    outFile.Close();
                    writer.Close();
                }
            }
        }
    }
}

  
